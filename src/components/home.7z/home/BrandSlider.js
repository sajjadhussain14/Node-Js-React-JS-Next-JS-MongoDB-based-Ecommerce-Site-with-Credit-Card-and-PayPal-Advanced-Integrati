import React from "react";
import dynamic from "next/dynamic";
//const OwlCarousel1 = dynamic(import("react-owl-carousel"), { ssr: false });
const OwlCarousel = dynamic(() => import("react-owl-carousel"), {
  ssr: false,
});

import Head from "next/head";
import Image from "next/image";

const BrandSlider = () => {
  <Head></Head>;
  let { URL } = process.env;
  return (
    <>
      <section id="brandslider">
      <div class="container">
      <div class="row">  
      <div class="col-12 heading">
				<h3>brands</h3>
			</div>
      <OwlCarousel
        className="owl-theme"
        loop
        margin={10}
        items={7}
        nav={true}
        navText={[
          '<img src="/images/Arrow_left.png" />',
          '<img src="/images/Arrow_right.png" />',
        ]}
        dots={false}
        animateIn={true}
      >
        <div className="item" style={{ width: "232px", marginRight: "10px" }}>
          <img
            alt="brand logo"
            src={URL+"/images/brands/Bromley mountain logo.png"}
            className="img-fluid"
          />
        </div>
        <div className="item" style={{ width: "232px", marginRight: "10px" }}>
          <img
            alt="brand logo"
            src={URL+"/images/brands/hunter-mountain.png"}
            className="img-fluid"
          />
        </div>
        <div className="item" style={{ width: "232px", marginRight: "10px" }}>
          <img
            alt="brand logo"
            src={URL+"/images/brands/jiminy.png"}
            className="img-fluid"
          />
        </div>
        <div className="item" style={{ width: "232px", marginRight: "10px" }}>
          <img
            alt="brand logo"
            src={URL+"/images/brands/PFM-Okemo.png"}
            width={90}
            height={63}
            layout="responsive"
            loading="lazy"
            className="img-fluid"
          />
        </div>
        <div className="item" style={{ width: "232px", marginRight: "10px" }}>
          <img
            alt="brand logo"
            src={URL+"/images/brands/PFM-Okemo.png"}
            className="img-fluid"
          />
        </div>
        <div className="item" style={{ width: "232px", marginRight: "10px" }}>
          <img
            alt="brand logo"
            src={URL+"/images/brands/stwejpg.png"}
            className="img-fluid"
          />
        </div>
        <div className="item" style={{ width: "232px", marginRight: "10px" }}>
          <img
            alt="brand logo"
            src={URL+"/images/brands/white-face.png"}
            className="img-fluid"
          />
        </div>
        <div className="item" style={{ width: "232px", marginRight: "10px" }}>
          <img
            alt="brand logo"
            src="https://template1.cumulusbetasites.com/ccms/default/assets/Image/brand-smith-and-wesson.png"
            className="img-fluid"
          />
        </div>{" "}
        <div className="item" style={{ width: "232px", marginRight: "10px" }}>
          <img
            alt="brand logo"
            src="https://template1.cumulusbetasites.com/ccms/default/assets/Image/brand-smith-and-wesson.png"
            className="img-fluid"
          />
        </div>{" "}
        <div className="item" style={{ width: "232px", marginRight: "10px" }}>
          <img
            alt="brand logo"
            src="https://template1.cumulusbetasites.com/ccms/default/assets/Image/brand-smith-and-wesson.png"
            className="img-fluid"
          />
        </div>{" "}
        <div className="item" style={{ width: "232px", marginRight: "10px" }}>
          <img
            alt="brand logo"
            src="https://template1.cumulusbetasites.com/ccms/default/assets/Image/brand-smith-and-wesson.png"
            className="img-fluid"
          />
        </div>{" "}
      </OwlCarousel>
      </div>
      </div>
      </section>
    </>
  );
};

export default BrandSlider;
