import React from "react";
import Link from "next/link";
import LoginPopUp from "../../pages/account/LoginPopUp";

const Middle = (props) => {
  let { URL } = process.env;

  let cartValue = [];
  if (typeof window != "undefined") {
    cartValue = JSON.parse(localStorage.getItem("cart"));
  }

  let loginstatus = "";
  if (typeof window != "undefined") {
    loginstatus = localStorage.getItem("isLogin");
  }
  if (!loginstatus) {
    loginstatus = "";
  }

  let cartItems = 0;
  try {
    cartItems = props.cartData.length;
  } catch (err) {}
  return (
    <>
      <LoginPopUp />

      <section id="middle">
        <div className="container">
          <div className="row">
            <div className="col-lg-3 col-md-3 col-sm-12 col-12 logo">
              <Link href={URL}>
                <a>
                  <p>
                    <img
                      alt=""
                      height="110"
                      src="https://template1.cumulusbetasites.com/ccms/default/assets/Image/logo.png"
                      width="100"
                    />
                  </p>
                </a>
              </Link>
            </div>
            <div className="col-lg-6 col-md-6 col-sm-12 col-12 search">
              <form role="search" action="" method="post" name="myForm">
                <input name="Search" placeholder="Search " type="text" />
                <button type="submit">
                <img src={URL+"/images/header_search_icon.png"} />
                </button>
              </form>
            </div>
            <div className="col-lg-3 col-md-3 col-sm-4 col-12 profile">
              {loginstatus && loginstatus == "yes" ? (
                <Link href={URL + "/account"}>
                  <a>
                    <i className="fas fa-user"></i>
                    My Account
                  </a>
                </Link>
              ) : (
                ""
              )}

              {!loginstatus || loginstatus != "yes" ? (
                <button
                  type="button"
                  data-toggle="modal"
                  data-target="#loginModal"
                  className="border-0 bg-transparent"
                >
                  <img src={URL+"/images/icon-account.png"} />
                  Sign in
                </button>
              ) : (
                ""
              )}
              <Link href={URL + "/cart"}>
                <a id="header-cart">
                <img src={URL+"/images/icon-cart.png"} />cart
                  
                </a>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Middle;
